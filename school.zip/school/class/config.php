<?php
class dbConfig {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
    function dbConfig() {
    
    $this -> serverName = 'localhost';
                $this -> userName = 'Your User Name';
                $this -> password = "Your Password";
                $this -> dbName =   "Your Database Name";

    }
}
?>